sh validate.sh ../xsd/maindoc/UBL-Order-2.1.xsd order-test-good.xml
sh validate.sh ../xsd/maindoc/UBL-Order-2.1.xsd order-test-bad1.xml
sh validate.sh ../xsd/maindoc/UBL-Order-2.1.xsd order-test-bad2.xml

